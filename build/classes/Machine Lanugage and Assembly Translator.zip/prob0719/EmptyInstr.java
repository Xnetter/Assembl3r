/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prob0719;

/**
 *
 * @author ursin
 */
public class EmptyInstr extends ACode{
    // For an empty source line.
    public String generateListing()
    {
        return "";
    }
    public String generateCode()
    {
        return "";
    }
    
    
}
