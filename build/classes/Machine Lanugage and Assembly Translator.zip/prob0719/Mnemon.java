/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prob0719;

/**
 *
 * @author ursin
 */
public enum Mnemon {
    M_STOP, M_ASLA, M_ASRA, M_BR, M_BRLT, M_BREQ, M_BRLE, M_CPWA, M_DECI, M_DECO, M_ADDA, M_SUBA, M_STWA, M_LDWA, M_BLOCK, M_END;
}
