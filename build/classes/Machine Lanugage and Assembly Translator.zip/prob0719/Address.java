/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prob0719;

/**
 *
 * @author ursin
 */
public enum Address {
    AD_I, AD_D, AD_N, AD_S, AD_SF, AD_X, AD_SX, AD_SFX;
}
